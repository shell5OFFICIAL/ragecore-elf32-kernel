#ifndef COPILOT_H
#define COPILOT_H

void square(int color, int sx, int dx, int sy, int dy);
void rputc(char c, int x, int y, int color);
void putc(char c);
void puts(const char* s);


#endif