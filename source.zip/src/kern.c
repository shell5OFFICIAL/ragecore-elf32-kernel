#include "copilot.h"

void kmf(void) {
    puts("hi welcome to ragecore!, this is still in development please report any bugs!");
    square(0x1F, 30, 45, 10, 15);
}