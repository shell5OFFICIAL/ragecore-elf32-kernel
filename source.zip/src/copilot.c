#include "copilot.h"
volatile char *video = (volatile char*)0xB8000;
int i=0;
int x=0;
int y=0;

void rputc(char c, int x, int y, int color) 
{
    int offset=y*80*2+x*2;
    video[offset]=c;
    video[offset+1]=color;
}
void putc(char c)
{
    if(c=='\n')
    {
        x=0;
        y++;
        if(y>=25)
        {
            y=0;
            x=0;
        }
    }
    rputc(c,x,y,0x07);
    x++;
    if(x>=80)
    {
        x=0;
        y++;
    }
}
void puts(const char* s) 
{
    while(*s)
    {
        putc(*s);
        s++;
    }
}

void square(int color, int sx, int dx, int sy, int dy)
{
    x=sx;
    y=sy;
    for(x=sx;x<dx;x++)
    {
        rputc(' ', x,y,color);
        for(y=sy;y<dy;y++)
        {
            rputc(' ',x,y,color);
        }
    }
    x=0;
    y=0;
}